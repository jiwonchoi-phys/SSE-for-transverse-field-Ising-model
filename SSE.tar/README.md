# SSE-for-transverse-field-Ising-model
## UNDER CONSTRUCTION
